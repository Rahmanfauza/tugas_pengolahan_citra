import pygame
import sys
import math

# Inisialisasi Pygame
pygame.init()

# Konstanta untuk ukuran jendela
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("3D Box Rotation Example")

# Warna
BLUE = (0, 0, 255)
DARK_GRAY = (50, 50, 50)
BLACK = (0, 0, 0)

# Posisi dan sudut kotak
x = 400
y = 300
angle_x = 0  # Sudut rotasi sumbu X
angle_y = 0  # Sudut rotasi sumbu Y

# Fungsi untuk melakukan rotasi 3D
def rotate_point(point, angle_x, angle_y):
    # Rotasi pada sumbu Y
    x_rotated = point[0] * math.cos(math.radians(angle_y)) - point[2] * math.sin(math.radians(angle_y))
    z_rotated = point[0] * math.sin(math.radians(angle_y)) + point[2] * math.cos(math.radians(angle_y))
    y_rotated = point[1]  # Y tidak berubah dalam rotasi sumbu Y

    # Rotasi pada sumbu X
    y_rotated_new = y_rotated * math.cos(math.radians(angle_x)) - z_rotated * math.sin(math.radians(angle_x))
    z_rotated_new = y_rotated * math.sin(math.radians(angle_x)) + z_rotated * math.cos(math.radians(angle_x))
    
    return (x_rotated, y_rotated_new, z_rotated_new)

# Fungsi untuk menggambar kotak yang telah diputar
def draw_rotated_box(x, y, angle_x, angle_y):
    # Ukuran kotak
    size = 100
    offset = 20  # Offset untuk bagian belakang
    
    # Titik-titik untuk kotak
    points = [
        (-size / 2, -size / 2, -size / 2),  # Kiri atas depan
        (size / 2, -size / 2, -size / 2),   # Kanan atas depan
        (size / 2, size / 2, -size / 2),    # Kanan bawah depan
        (-size / 2, size / 2, -size / 2),   # Kiri bawah depan
        (-size / 2, -size / 2, size / 2),   # Kiri atas belakang
        (size / 2, -size / 2, size / 2),    # Kanan atas belakang
        (size / 2, size / 2, size / 2),     # Kanan bawah belakang
        (-size / 2, size / 2, size / 2)     # Kiri bawah belakang
    ]

    # Rotasi semua titik kotak
    rotated_points = [rotate_point(point, angle_x, angle_y) for point in points]

    # Menghitung posisi titik pada layar
    projected_points = []
    for point in rotated_points:
        # Proyeksi 3D ke 2D
        factor = 200 / (200 + point[2])  # Faktor proyeksi
        x_proj = x + point[0] * factor
        y_proj = y - point[1] * factor  # Mengubah arah Y untuk kesesuaian tampilan
        projected_points.append((x_proj, y_proj))

    # Menggambar bagian depan kotak
    pygame.draw.polygon(screen, BLUE, projected_points[:4])  # Bagian depan
    pygame.draw.polygon(screen, DARK_GRAY, projected_points[4:])  # Bagian belakang

    # Menghubungkan sisi depan dan belakang
    for i in range(4):
        pygame.draw.line(screen, BLACK, projected_points[i], projected_points[i + 4], 1)

# Loop utama
while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

    # Mendapatkan status tombol
    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT]:
        angle_y -= 5  # Mengurangi sudut rotasi sumbu Y untuk memutar ke kiri
    if keys[pygame.K_RIGHT]:
        angle_y += 5  # Menambah sudut rotasi sumbu Y untuk memutar ke kanan
    if keys[pygame.K_UP]:
        angle_x -= 5  # Mengurangi sudut rotasi sumbu X untuk memutar ke atas
    if keys[pygame.K_DOWN]:
        angle_x += 5  # Menambah sudut rotasi sumbu X untuk memutar ke bawah

    # Menggambar ulang layar
    screen.fill((255, 255, 255))  # Mengisi latar belakang dengan warna putih
    draw_rotated_box(x, y, angle_x, angle_y)  # Menggambar kotak yang diputar
    pygame.display.flip()  # Memperbarui tampilan

    # Mengatur frame rate
    pygame.time.Clock().tick(30)
