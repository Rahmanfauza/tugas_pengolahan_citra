import pygame
import sys
import math

# Inisialisasi Pygame
pygame.init()

# Konstanta untuk ukuran jendela
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("3D Box Rotation Example")

# Warna
BLUE = (0, 0, 255)
DARK_GRAY = (50, 50, 50)
BLACK = (0, 0, 0)

# Posisi dan sudut kotak
x = 400
y = 300
angle = 0  # Sudut rotasi

# Fungsi untuk menggambar kotak yang telah diputar
def draw_rotated_box(x, y, angle):
    # Ukuran kotak
    size = 100
    offset = 20  # Offset untuk bagian belakang
    
    # Menghitung sudut dalam radian
    rad = math.radians(angle)
    
    # Titik-titik untuk bagian depan kotak
    front_top_left = (x - size / 2, y - size / 2)
    front_top_right = (x + size / 2, y - size / 2)
    front_bottom_left = (x - size / 2, y + size / 2)
    front_bottom_right = (x + size / 2, y + size / 2)
    
    # Menghitung titik-titik belakang dengan rotasi
    back_top_left = (front_top_left[0] + offset * math.cos(rad), front_top_left[1] + offset * math.sin(rad))
    back_top_right = (front_top_right[0] + offset * math.cos(rad), front_top_right[1] + offset * math.sin(rad))
    back_bottom_left = (front_bottom_left[0] + offset * math.cos(rad), front_bottom_left[1] + offset * math.sin(rad))
    back_bottom_right = (front_bottom_right[0] + offset * math.cos(rad), front_bottom_right[1] + offset * math.sin(rad))

    # Menggambar bagian depan kotak
    pygame.draw.rect(screen, BLUE, (front_top_left[0], front_top_left[1], size, size))  # Bagian depan
    
    # Menggambar bagian belakang kotak
    pygame.draw.rect(screen, DARK_GRAY, (back_top_left[0], back_top_left[1], size, size))  # Bagian belakang

    # Menghubungkan sisi depan dan belakang
    pygame.draw.line(screen, BLACK, front_top_left, back_top_left, 1)  # Kiri atas
    pygame.draw.line(screen, BLACK, front_top_right, back_top_right, 1)  # Kanan atas
    pygame.draw.line(screen, BLACK, front_bottom_left, back_bottom_left, 1)  # Kiri bawah
    pygame.draw.line(screen, BLACK, front_bottom_right, back_bottom_right, 1)  # Kanan bawah

# Loop utama
while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

    # Mendapatkan status tombol
    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT]:
        angle -= 5  # Mengurangi sudut untuk memutar ke kiri
    if keys[pygame.K_RIGHT]:
        angle += 5  # Menambah sudut untuk memutar ke kanan

    # Menggambar ulang layar
    screen.fill((255, 255, 255))  # Mengisi latar belakang dengan warna putih
    draw_rotated_box(x, y, angle)  # Menggambar kotak yang diputar
    pygame.display.flip()  # Memperbarui tampilan

    # Mengatur frame rate
    pygame.time.Clock().tick(30)
