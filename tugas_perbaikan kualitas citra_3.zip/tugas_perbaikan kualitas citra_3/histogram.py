import cv2
import os

class ImageEnhancer:
    def __init__(self, image_path):
        self.image_path = image_path
        self.image = cv2.imread(image_path)

        if self.image is None:
            raise ValueError(f"Gagal membaca citra dari: {image_path}")

    def enhance_image(self):
        # Mengonversi citra ke ruang warna abu-abu
        gray_image = cv2.cvtColor(self.image, cv2.COLOR_BGR2GRAY)

        # Menerapkan histogram equalization
        enhanced_image = cv2.equalizeHist(gray_image)

        print(f"Enhanced image shape: {enhanced_image.shape}")  # Debugging
        return enhanced_image

    def save_enhanced_image(self, enhanced_image, output_path):
        cv2.imwrite(output_path, enhanced_image)
        print(f"Citra berhasil diperbaiki dan disimpan di: {output_path}")

# Contoh penggunaan
if __name__ == "__main__":
    input_image_path = "about.jpg"

    # Menentukan direktori dan nama file output
    output_directory = os.path.dirname(input_image_path)  # Mendapatkan folder yang sama dengan input
    output_image_name = "enhanced_about.jpg"
    output_image_path = os.path.join(output_directory, output_image_name)

    enhancer = ImageEnhancer(input_image_path)
    enhanced_image = enhancer.enhance_image()
    enhancer.save_enhanced_image(enhanced_image, output_image_path)
