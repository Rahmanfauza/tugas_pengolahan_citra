import cv2
import os

class BrightnessAdjuster:
    def __init__(self, image_path):
        self.image_path = image_path
        self.image = cv2.imread(image_path)

        if self.image is None:
            raise ValueError(f"Gagal membaca citra dari: {image_path}")

    def adjust_brightness(self, brightness_value):
        """
        Mengubah kecerahan gambar.
        
        :param brightness_value: Nilai kecerahan untuk ditambahkan atau dikurangi. Bisa negatif untuk mengurangi.
        """
        brightness_adjusted_image = cv2.convertScaleAbs(self.image, alpha=1, beta=brightness_value)
        return brightness_adjusted_image

    def save_image(self, image, output_path):
        cv2.imwrite(output_path, image)
        print(f"Citra berhasil disimpan di: {output_path}")

# Contoh penggunaan
if __name__ == "__main__":
    input_image_path = "about.jpg"

    # Menentukan direktori dan nama file output
    output_directory = os.path.dirname(input_image_path)  # Mendapatkan folder yang sama dengan input
    output_image_name = "brightness_adjusted_about.jpg"
    output_image_path = os.path.join(output_directory, output_image_name)

    adjuster = BrightnessAdjuster(input_image_path)
    brightness_value = 50  # Positif untuk meningkatkan, negatif untuk mengurangi
    brightness_adjusted_image = adjuster.adjust_brightness(brightness_value)
    adjuster.save_image(brightness_adjusted_image, output_image_path)
