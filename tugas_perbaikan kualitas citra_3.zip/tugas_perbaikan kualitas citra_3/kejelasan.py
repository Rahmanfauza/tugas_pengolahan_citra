import cv2
import numpy as np
import os

class ImageSharpener:
    def __init__(self, image_path):
        self.image_path = image_path
        self.image = cv2.imread(image_path)

        if self.image is None:
            raise ValueError(f"Gagal membaca citra dari: {image_path}")

    def sharpen_image(self):
        """
        Menajamkan citra menggunakan filter kernel.
        """
        # Kernel untuk menajamkan gambar
        sharpening_kernel = np.array([[0, -1, 0], 
                                      [-1, 5, -1],
                                      [0, -1, 0]])

        # Menerapkan filter sharpening pada citra
        sharpened_image = cv2.filter2D(self.image, -1, sharpening_kernel)
        return sharpened_image

    def save_image(self, image, output_path):
        cv2.imwrite(output_path, image)
        print(f"Citra berhasil disimpan di: {output_path}")

# Contoh penggunaan
if __name__ == "__main__":
    input_image_path = "about.jpg"  # Input image path
    
    # Menentukan direktori dan nama file output
    output_directory = os.path.dirname(input_image_path)  # Mendapatkan folder yang sama dengan input
    output_image_name = "sharpened_about.jpg"
    output_image_path = os.path.join(output_directory, output_image_name)

    sharpener = ImageSharpener(input_image_path)
    sharpened_image = sharpener.sharpen_image()
    sharpener.save_image(sharpened_image, output_image_path)
