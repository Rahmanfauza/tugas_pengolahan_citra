import cv2
import numpy as np

# Membaca citra dari jalur yang benar
image = cv2.imread(r"C:\Users\rahma\Desktop\tugas_perbaikan_citra_2\3010279.jpg")

# Memeriksa apakah citra berhasil dibaca
if image is None:
    print("Gagal membaca citra. Periksa jalur file.")
else:
    # Pengubahan Kecerahan
    brightness_value = 50  # nilai positif untuk mencerahkan, negatif untuk gelap
    brightened_image = cv2.convertScaleAbs(image, alpha=1, beta=brightness_value)
    cv2.imwrite(r"C:\Users\rahma\Desktop\tugas_perbaikan_citra_2\brightened_image.jpg", brightened_image)

    # Konversi citra ke grayscale untuk pemrosesan lebih lanjut
    gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    cv2.imwrite(r"C:\Users\rahma\Desktop\tugas_perbaikan_citra_2\gray_image.jpg", gray_image)

    # Peregangan Kontras
    min_val, max_val = cv2.minMaxLoc(gray_image)[0:2]
    contrast_stretched = cv2.convertScaleAbs(gray_image, alpha=255 / (max_val - min_val), beta=-min_val * (255 / (max_val - min_val)))
    cv2.imwrite(r"C:\Users\rahma\Desktop\tugas_perbaikan_citra_2\contrast_stretched.jpg", contrast_stretched)

    # Pengubahan Histogram
    hist_eq_image = cv2.equalizeHist(gray_image)
    cv2.imwrite(r"C:\Users\rahma\Desktop\tugas_perbaikan_citra_2\hist_eq_image.jpg", hist_eq_image)

    # Pelembutan Citra
    blurred_image = cv2.GaussianBlur(image, (5, 5), 0)
    cv2.imwrite(r"C:\Users\rahma\Desktop\tugas_perbaikan_citra_2\blurred_image.jpg", blurred_image)

    # Penajaman Citra
    sharpened_image = cv2.addWeighted(image, 1.5, blurred_image, -0.5, 0)
    cv2.imwrite(r"C:\Users\rahma\Desktop\tugas_perbaikan_citra_2\sharpened_image.jpg", sharpened_image)

    # Pewarnaan Semu
    pseudocolored_image = cv2.applyColorMap(gray_image, cv2.COLORMAP_JET)
    cv2.imwrite(r"C:\Users\rahma\Desktop\tugas_perbaikan_citra_2\pseudocolored_image.jpg", pseudocolored_image)

    # Pengubahan Geometrik (Rotasi)
    height, width = image.shape[:2]
    rotation_matrix = cv2.getRotationMatrix2D((width / 2, height / 2), 45, 1)  # rotasi 45 derajat
    rotated_image = cv2.warpAffine(image, rotation_matrix, (width, height))
    cv2.imwrite(r"C:\Users\rahma\Desktop\tugas_perbaikan_citra_2\rotated_image.jpg", rotated_image)

    # Menampilkan hasil
    cv2.imshow("Original Image", image)
    cv2.imshow("Brightened Image", brightened_image)
    cv2.imshow("Contrast Stretched", contrast_stretched)
    cv2.imshow("Histogram Equalized", hist_eq_image)
    cv2.imshow("Blurred Image", blurred_image)
    cv2.imshow("Sharpened Image", sharpened_image)
    cv2.imshow("Pseudocolored Image", pseudocolored_image)
    cv2.imshow("Rotated Image", rotated_image)

    # Tunggu sampai pengguna menekan tombol
    cv2.waitKey(0)
    cv2.destroyAllWindows()
